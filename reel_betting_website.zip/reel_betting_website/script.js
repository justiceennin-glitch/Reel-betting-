const modal=document.getElementById('modal');
function showModal(title,text){document.getElementById('modalTitle').textContent=title;document.getElementById('modalText').textContent=text;modal.showModal()}
document.getElementById('joinBtn').addEventListener('click',()=>showModal('Join Reel Betting','Registration is a demo only. A secure backend and privacy protections must be added before real accounts are enabled.'));
document.getElementById('loginBtn').addEventListener('click',()=>showModal('Login','Login is not connected yet. Do not enter or share passwords on this demo website.'));
document.getElementById('closeModal').addEventListener('click',()=>modal.close());
document.getElementById('okModal').addEventListener('click',()=>modal.close());
document.querySelectorAll('.league').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.league').forEach(x=>x.classList.remove('active'));btn.classList.add('active');document.querySelectorAll('.match').forEach(m=>m.hidden=btn.dataset.league!=='all'&&m.dataset.country!==btn.dataset.league)}));
document.querySelectorAll('.odds button').forEach(btn=>btn.addEventListener('click',()=>{btn.classList.toggle('chosen');showModal('Sample selection',btn.dataset.odd+' selected for this visual demo. No bet is placed and no money is accepted.')}));
document.querySelectorAll('[data-game]').forEach(btn=>btn.addEventListener('click',()=>showModal(btn.dataset.game,'This is a game-category placeholder. Connect a properly licensed game provider if appropriate; no playable gambling game is included.')));
document.getElementById('copyCode').addEventListener('click',async()=>{try{await navigator.clipboard.writeText('RB7K2A');showModal('Copied','Sample code RB7K2A copied. It is not redeemable.')}catch(e){showModal('Sample code','RB7K2A — example only, not redeemable.')}});

// Local-only demo wallet. It never connects to a payment provider or transfers real money.
let demoBalance = Number(localStorage.getItem('rb_demo_balance') || '0');
let demoTransactions = [];
try { demoTransactions = JSON.parse(localStorage.getItem('rb_demo_transactions') || '[]'); } catch(e) { demoTransactions = []; }
let walletMode = 'deposit';
const money = n => 'GHS ' + Number(n).toLocaleString('en-GH',{minimumFractionDigits:2,maximumFractionDigits:2});
function renderWallet(){
  const balanceEl=document.getElementById('walletBalance');
  if(!balanceEl) return;
  balanceEl.textContent=money(demoBalance);
  const history=document.getElementById('transactionHistory');
  if(!demoTransactions.length){history.innerHTML='<p class="empty-history">Your demo transactions will appear here.</p>';return;}
  history.innerHTML=demoTransactions.slice().reverse().map(t=>`<div class="transaction-row"><div><b>${t.title}</b><small>${t.date}</small></div><span class="transaction-amount ${t.amount>=0?'plus':'minus'}">${t.amount>=0?'+':'−'}${money(Math.abs(t.amount))}</span></div>`).join('');
}
function openWalletForm(mode){
  walletMode=mode;
  document.getElementById('walletFormTitle').textContent=mode==='deposit'?'Add demo funds':'Withdraw demo funds';
  document.getElementById('walletAmount').value='';
  document.getElementById('walletForm').hidden=false;
  document.getElementById('walletAmount').focus();
}
document.getElementById('depositBtn')?.addEventListener('click',()=>openWalletForm('deposit'));
document.getElementById('withdrawBtn')?.addEventListener('click',()=>openWalletForm('withdraw'));
document.getElementById('cancelWallet')?.addEventListener('click',()=>{document.getElementById('walletForm').hidden=true;});
document.getElementById('confirmWallet')?.addEventListener('click',()=>{
  const input=document.getElementById('walletAmount');
  const amount=Number(input.value);
  if(!Number.isFinite(amount)||amount<=0){showModal('Enter an amount','Enter a demo amount greater than zero. No real money is involved.');return;}
  if(walletMode==='withdraw'&&amount>demoBalance){showModal('Insufficient demo balance','Your demo wallet does not have enough funds for this demo withdrawal.');return;}
  const signed=walletMode==='deposit'?amount:-amount;
  demoBalance=Number((demoBalance+signed).toFixed(2));
  demoTransactions.push({title:walletMode==='deposit'?'Demo deposit':'Demo withdrawal',amount:signed,date:new Date().toLocaleString()});
  localStorage.setItem('rb_demo_balance',String(demoBalance));
  localStorage.setItem('rb_demo_transactions',JSON.stringify(demoTransactions));
  document.getElementById('walletForm').hidden=true;
  renderWallet();
  showModal('Demo transaction complete',`${walletMode==='deposit'?'Added':'Removed'} ${money(amount)} in demo funds. No real payment or transfer occurred.`);
});
document.getElementById('clearHistory')?.addEventListener('click',()=>{
  demoTransactions=[];localStorage.setItem('rb_demo_transactions','[]');renderWallet();
});
renderWallet();
